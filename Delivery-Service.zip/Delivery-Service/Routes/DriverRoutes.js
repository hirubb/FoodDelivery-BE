// routes/driver.routes.js
const express = require('express');
const driverController = require('../Controllers/DriverController');
const auth = require('../middleware/auth');

const router = express.Router();

// All routes are protected
router.use(auth);

// Get driver profile with vehicle info
router.get('/profile', driverController.getDriverProfile);

// Update driver profile
router.put('/profile', driverController.updateProfile);

// Get driver statistics
router.get('/stats', driverController.getStats);

// Update driver location
router.put('/location', driverController.updateLocation);

module.exports = router;
