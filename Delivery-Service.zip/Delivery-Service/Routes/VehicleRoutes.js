// routes/vehicle.routes.js
const express = require('express');
const { body } = require('express-validator');
const vehicleController = require('../Controllers/VehicleController');
const auth = require('../middleware/auth');

const router = express.Router();

// All routes are protected
router.use(auth);

// Register new vehicle with validation
router.post(
    '/',
    [
        body('vehicleType').isIn(['motorbike', 'car', 'van', 'tuk/auto']).withMessage('Invalid vehicle type'),
        body('vehicleModel').not().isEmpty().withMessage('Vehicle model is required'),
        body('manufactureYear').isInt({ min: 1990 }).withMessage('Manufacture year must be 1990 or later'),
        body('licensePlate').not().isEmpty().withMessage('License plate is required')
    ],
    vehicleController.registerVehicle
);

// Get vehicle details
router.get('/', vehicleController.getVehicle);

// Update vehicle details
router.put('/', vehicleController.updateVehicle);

// Upload vehicle documents
router.post('/documents', vehicleController.uploadDocuments);

module.exports = router;
