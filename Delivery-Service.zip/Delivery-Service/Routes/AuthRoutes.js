// routes/auth.routes.js
const express = require('express');
const { body } = require('express-validator');
const authController = require('../Controllers/AuthController');
const auth = require('../middleware/auth');

const router = express.Router();

// Register route with validation
router.post(
    '/register',
    [
        body('firstName').not().isEmpty().withMessage('First name is required'),
        body('lastName').not().isEmpty().withMessage('Last name is required'),
        body('email').isEmail().withMessage('Please enter a valid email'),
        body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
        body('mobile').not().isEmpty().withMessage('Mobile number is required'),
        body('age').isInt({ min: 18 }).withMessage('You must be at least 18 years old'),
        body('gender').isIn(['male', 'female', 'other']).withMessage('Gender must be male, female, or other')
    ],
    authController.register
);

// Login route
router.post(
    '/login',
    [
        body('email').isEmail().withMessage('Please enter a valid email'),
        body('password').not().isEmpty().withMessage('Password is required')
    ],
    authController.login
);

// Get profile route (protected)
router.get('/profile', auth, authController.getProfile);

// Logout route (protected)
router.post('/logout', auth, authController.logout);

module.exports = router;
