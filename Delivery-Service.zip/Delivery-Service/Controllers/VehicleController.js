// controllers/vehicle.controller.js
const Vehicle = require('../Models/Vehicle');
const { validationResult } = require('express-validator');

// Register new vehicle
exports.registerVehicle = async (req, res) => {
    try {
        // Check for validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const {
            vehicleType,
            vehicleModel,
            manufactureYear,
            licensePlate
        } = req.body;

        // Check if vehicle already registered for this driver
        let existingVehicle = await Vehicle.findOne({ driver: req.user._id });
        if (existingVehicle) {
            return res.status(400).json({ message: 'Vehicle already registered for this driver' });
        }

        // Create new vehicle
        const vehicle = new Vehicle({
            driver: req.user._id,
            vehicleType,
            vehicleModel,
            manufactureYear,
            licensePlate
        });

        await vehicle.save();

        res.status(201).json({
            message: 'Vehicle registered successfully',
            vehicle
        });
    } catch (error) {
        console.error('Error in registerVehicle:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Get vehicle details
exports.getVehicle = async (req, res) => {
    try {
        const vehicle = await Vehicle.findOne({ driver: req.user._id });

        if (!vehicle) {
            return res.status(404).json({ message: 'Vehicle not found' });
        }

        res.json(vehicle);
    } catch (error) {
        console.error('Error in getVehicle:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Update vehicle details
exports.updateVehicle = async (req, res) => {
    try {
        const updates = Object.keys(req.body);
        const allowedUpdates = ['vehicleType', 'vehicleModel', 'manufactureYear', 'licensePlate'];

        // Check if updates are valid
        const isValidOperation = updates.every(update => allowedUpdates.includes(update));
        if (!isValidOperation) {
            return res.status(400).json({ message: 'Invalid updates' });
        }

        const vehicle = await Vehicle.findOne({ driver: req.user._id });

        if (!vehicle) {
            return res.status(404).json({ message: 'Vehicle not found' });
        }

        // Apply updates
        updates.forEach(update => vehicle[update] = req.body[update]);
        await vehicle.save();

        res.json({
            message: 'Vehicle updated successfully',
            vehicle
        });
    } catch (error) {
        console.error('Error in updateVehicle:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Upload vehicle documents
exports.uploadDocuments = async (req, res) => {
    try {
        // This would typically be handled by a file upload middleware like multer
        // For this example, we'll assume the file URLs are provided in the request

        const {
            insuranceFile,
            insuranceExpiry,
            revenueLicenseFile,
            revenueLicenseExpiry,
            driverLicenseFrontFile,
            driverLicenseBackFile,
            driverLicenseExpiry,
            emissionCertificateFile,
            emissionCertificateExpiry,
            frontViewImage,
            sideViewImage
        } = req.body;

        const vehicle = await Vehicle.findOne({ driver: req.user._id });

        if (!vehicle) {
            return res.status(404).json({ message: 'Vehicle not found' });
        }

        // Update document files and expiry dates
        if (insuranceFile && insuranceExpiry) {
            vehicle.documents.insurance.file = insuranceFile;
            vehicle.documents.insurance.expiryDate = new Date(insuranceExpiry);
        }

        if (revenueLicenseFile && revenueLicenseExpiry) {
            vehicle.documents.revenueLicense.file = revenueLicenseFile;
            vehicle.documents.revenueLicense.expiryDate = new Date(revenueLicenseExpiry);
        }

        if (driverLicenseFrontFile && driverLicenseBackFile && driverLicenseExpiry) {
            vehicle.documents.driverLicense.frontFile = driverLicenseFrontFile;
            vehicle.documents.driverLicense.backFile = driverLicenseBackFile;
            vehicle.documents.driverLicense.expiryDate = new Date(driverLicenseExpiry);
        }

        if (emissionCertificateFile && emissionCertificateExpiry) {
            vehicle.documents.emissionCertificate.file = emissionCertificateFile;
            vehicle.documents.emissionCertificate.expiryDate = new Date(emissionCertificateExpiry);
        }

        // Update vehicle images
        if (frontViewImage) {
            vehicle.images.frontView = frontViewImage;
        }

        if (sideViewImage) {
            vehicle.images.sideView = sideViewImage;
        }

        await vehicle.save();

        res.json({
            message: 'Documents uploaded successfully',
            vehicle
        });
    } catch (error) {
        console.error('Error in uploadDocuments:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};
