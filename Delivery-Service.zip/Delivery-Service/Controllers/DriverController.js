// controllers/driver.controller.js
const User = require('../Models/Driver');
const Vehicle = require('../Models/Vehicle');
const Order = require('../Models/Order');
const Earnings = require('../Models/Earning');

// Get driver profile with vehicle info
exports.getDriverProfile = async (req, res) => {
    try {
        await req.user.populate('vehicle').execPopulate();
        res.json({
            user: req.user,
            vehicle: req.user.vehicle
        });
    } catch (error) {
        console.error('Error in getDriverProfile:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Update driver profile
exports.updateProfile = async (req, res) => {
    try {
        const updates = Object.keys(req.body);
        const allowedUpdates = ['firstName', 'lastName', 'mobile', 'profileImage'];

        // Check if updates are valid
        const isValidOperation = updates.every(update => allowedUpdates.includes(update));
        if (!isValidOperation) {
            return res.status(400).json({ message: 'Invalid updates' });
        }

        // Apply updates
        updates.forEach(update => req.user[update] = req.body[update]);
        await req.user.save();

        res.json({
            message: 'Profile updated successfully',
            user: req.user
        });
    } catch (error) {
        console.error('Error in updateProfile:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Get driver statistics
exports.getStats = async (req, res) => {
    try {
        // Get completed orders count
        const completedOrders = await Order.countDocuments({
            driver: req.user._id,
            status: 'completed'
        });

        // Get earnings summary
        const earnings = await Earnings.aggregate([
            { $match: { driver: req.user._id } },
            {
                $group: {
                    _id: null,
                    totalEarnings: { $sum: '$totalEarning' },
                    totalTips: { $sum: '$tip' },
                    totalBonus: { $sum: '$bonus' },
                    count: { $sum: 1 }
                }
            }
        ]);

        // Get recent orders
        const recentOrders = await Order.find({ driver: req.user._id })
            .sort({ updatedAt: -1 })
            .limit(5);

        res.json({
            stats: {
                completedOrders,
                earnings: earnings.length > 0 ? {
                    total: earnings[0].totalEarnings,
                    tips: earnings[0].totalTips,
                    bonus: earnings[0].totalBonus,
                    count: earnings[0].count
                } : {
                    total: 0,
                    tips: 0,
                    bonus: 0,
                    count: 0
                }
            },
            recentOrders
        });
    } catch (error) {
        console.error('Error in getStats:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Update driver location
exports.updateLocation = async (req, res) => {
    try {
        const { latitude, longitude } = req.body;

        if (!latitude || !longitude) {
            return res.status(400).json({ message: 'Latitude and longitude are required' });
        }

        // You could save this to a separate driver location model
        // or to the user model directly if you add location fields

        res.json({
            message: 'Location updated successfully',
            location: { latitude, longitude }
        });
    } catch (error) {
        console.error('Error in updateLocation:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};
