// models/vehicle.model.js
const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema({
    driver: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    vehicleType: {
        type: String,
        enum: ['motorbike', 'car/van', 'tuk/auto'],
        required: true
    },
    vehicleModel: {
        type: String,
        required: true
    },
    manufactureYear: {
        type: Number,
        required: true
    },
    licensePlate: {
        type: String,
        required: true,
        unique: true
    },
    images: {
        frontView: {
            type: String
        },
        sideView: {
            type: String
        }
    },
    documents: {
        insurance: {
            file: String,
            expiryDate: {
                type: Date,
                default: null
            },
            verified: {
                type: Boolean,
                default: false
            }
        },
        revenueLicense: {
            file: String,
            expiryDate: {
                type: Date,
                default: null
            },
            verified: {
                type: Boolean,
                default: false
            }
        },
        driverLicense: {
            frontFile: String,
            backFile: String,
            expiryDate: {
                type: Date,
                default: null
            },
            verified: {
                type: Boolean,
                default: false
            }
        },
        emissionCertificate: {
            file: String,
            expiryDate: {
                type: Date,
                default: null
            },
            verified: {
                type: Boolean,
                default: false
            }
        }
    },
    status: {
        type: String,
        enum: ['pending', 'verified', 'rejected'],
        default: 'pending'
    }
}, {
    timestamps: true
});

const Vehicle = mongoose.model('Vehicle', vehicleSchema);

module.exports = Vehicle;
